
package Images;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.*;
import java.util.Scanner;

public class ImgToDB {

    
    private static final String Uname = "root"; 
    private static final String pass = "230659"; 
    private static final String url = "jdbc:mysql://localhost/student"; 
    public static void main(String[] args) throws SQLException, FileNotFoundException, IOException {
        
        Scanner sc = new Scanner(System.in);
        try
        {
        Connection con = DriverManager.getConnection(url,Uname,pass);
       Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            File f = new File("A:\\p1.png");
            FileInputStream fis = new FileInputStream("A:\\p1.png");
            
            byte b[] = new byte[(int)f.length()];
            fis.read(b);
            PreparedStatement pst = con.prepareStatement("insert into images values(?,?)");
            pst.setInt(1, 1);
            pst.setBytes(2, b);
            pst.execute();
       
       
       ResultSet rs = stmt.executeQuery("select img from images where id = 1");
         while(rs.next())
        {
            byte b1[] = rs.getBytes(1);
            FileOutputStream fout = new FileOutputStream("J:\\p1.png");
            fout.write(b);
            fout.close();
            
                    
        }


        }
        catch(SQLException e)
        {System.out.println(e);}
        
    }
}
