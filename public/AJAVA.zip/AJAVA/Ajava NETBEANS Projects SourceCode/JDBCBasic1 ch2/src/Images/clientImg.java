
package Images;
import java.io.*;  
import java.net.*;
import java.util.Scanner;
public class clientImg {
    
    public static void main(String args[])
    {Scanner sc = new Scanner(System.in);
            
            try{      
        Socket s=new Socket("localhost",8080);  
        DataOutputStream dout=new DataOutputStream(s.getOutputStream());  
        DataInputStream dis=new DataInputStream(s.getInputStream());  
        File f = new File("A:\\p1.png");
        FileInputStream fis = new FileInputStream("A:\\p1.png");
            
        byte b[] = new byte[(int)f.length()];
        fis.read(b);
        dout.writeInt(b.length);
        dout.write(b);
        
        
   
   
        
        
        dout.flush();  
        dout.close();  
        s.close();  
        }catch(Exception e){System.out.println(e);}     
    
    
    }
    
}
