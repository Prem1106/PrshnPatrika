
package Images;
import java.io.*;  
import java.net.*;

public class serverImg {

   
    public static void main(String[] args) {
        try{  
        ServerSocket ss=new ServerSocket(8080);  
        Socket s=ss.accept();//establishes connection   

System.out.println("hello");
        DataInputStream dis=new DataInputStream(s.getInputStream());  
//        String  str =(String)dis.readUTF();
//        byte b[]= new byte[5000] ;
//       int length = dis.readInt();
       byte b []= new byte[dis.readInt()]; 
       dis.readFully(b);
        
        
        FileOutputStream fout=new FileOutputStream("J:\\p1.png");  
         fout.write(b);
        ss.close();  
        }catch(Exception e){System.out.println(e);}  
    }
    
}
