
package RSMetaData;

import UpdatableRS.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class RSMD {
    public static void main(String[] args) {
       String URL = "jdbc:mysql://localhost/student";
        try {
     
            Connection con = DriverManager.getConnection(URL,"root",
                    "230659");
            System.out.println("connection done");
            Statement st = con.createStatement(
                    ResultSet.TYPE_SCROLL_SENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = st.executeQuery("select * from staff");
            ResultSetMetaData rsmd = rs.getMetaData();

            System.out.println("column name : "+rsmd.getColumnName(2));
            System.out.println("column type : "+rsmd.getColumnTypeName(2));
            System.out.println("column lable : "+rsmd.getColumnCount());
            System.out.println("column table name : "+rsmd.getTableName(2));
            
            
        } catch (SQLException ex) {
            Logger.getLogger(RSMD.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }
    
}
