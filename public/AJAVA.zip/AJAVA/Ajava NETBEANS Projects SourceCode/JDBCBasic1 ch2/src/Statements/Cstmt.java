
package Statements;

import java.sql.*;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Cstmt {
   static Scanner sc;
   static Connection con;
   static CallableStatement cstmt;
   static Statement st;
   
    static void display() throws SQLException
    {       cstmt = con.prepareCall("{call display1()}");
            ResultSet rs=cstmt.executeQuery();
            System.out.println("...... DATA ......");
            while(rs.next())
            {
                System.out.print(rs.getInt(1) + " ");
                System.out.print(rs.getString(2) + " ");
                System.out.println(rs.getString(3) + " ");
            }System.out.println("...................\n\n");
    
    }
    static void insert() throws SQLException
    {
            System.out.println("enter id : ");    
            int n=sc.nextInt();
            System.out.println("enter name : ");    
            String name = sc.next();
            System.out.println("enter number : ");    
            String num = sc.next();
            cstmt= con.prepareCall("{call insert1(?,?,?)}");
            cstmt.setInt(1, n);
            cstmt.setString(2, name);
            cstmt.setString(3, num);
            cstmt.execute();
       }
    
   static void update() throws SQLException
    {       System.out.println("enter id : ");    
            int n=sc.nextInt();
            System.out.println("enter name : ");    
            String name = sc.next();
            System.out.println("enter number : ");    
            String num = sc.next();
            cstmt= con.prepareCall("{call update1(?,?,?)}");
            cstmt.setInt(1, n);
            cstmt.setString(2, name);
            cstmt.setString(3, num);
            cstmt.execute();
            
            
            
    }
    static void delete() throws SQLException
    {
            System.out.println("enter id : ");    
            int n=sc.nextInt();
            cstmt= con.prepareCall("{call delete1(?)}");
            cstmt.setInt(1, n);
            cstmt.execute();
            
    }
    public static void main(String[] args) {
        try {
             sc=new Scanner(System.in);
             con=DriverManager.getConnection("jdbc:mysql://localhost/student", "root", "230659");
             st= con.createStatement();
             int choice;
             do
           {    System.out.print(" 1.Display \n 2.Insert\n 3.Update\n 4.Delete\n enter yout Choice : ");
               choice=sc.nextInt();
               if(choice==1)
                   display();
               if(choice==2)
                   insert();
               if(choice==3)
                   update();
               if(choice==4)
                   delete();
               if(choice==5)
                   find();
           }while(choice !=0);
             
                    
            } catch (SQLException ex) {
            Logger.getLogger(Cstmt.class.getName()).log(Level.SEVERE, null, ex);
        }
                
    }

     static void find() throws SQLException {
            System.out.println("enter id : ");    
            int n=sc.nextInt();
           CallableStatement cstmt1= con.prepareCall("{call getname(?,?)}");
            cstmt1.setInt(1, n);
            cstmt1.execute();
            System.out.println("Name : "+cstmt1.getString(2));
            
     }
    
}
