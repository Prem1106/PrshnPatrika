
package Statements;

import java.sql.*;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Pstmt {
   static Scanner sc;
   static Connection con;
   static PreparedStatement pst;
   static Statement st;
   
    static void display() throws SQLException
    {
        pst= con.prepareStatement("select * from students");
        ResultSet rs=pst.executeQuery();
            System.out.println("...... DATA ......");
            while(rs.next())
            {
                System.out.print(rs.getInt(1) + " ");
                System.out.print(rs.getString(2) + " ");
                System.out.println(rs.getString(3) + " ");
            }System.out.println("...................\n\n");
    
    }
    static void insert() throws SQLException
    {
            System.out.println("enter id : ");    
            int n=sc.nextInt();
            System.out.println("enter name : ");    
            String name = sc.next();
            System.out.println("enter number : ");    
            String num = sc.next();
            pst= con.prepareStatement("insert into students values (?,?,?)");
            pst.setInt(1, n);
            pst.setString(2, name);
            pst.setString(3, num);
            pst.execute();
       }
    
   static void update() throws SQLException
    {       System.out.println("enter id : ");    
            int n=sc.nextInt();
            System.out.println("enter name : ");    
            String name = sc.next();
            System.out.println("enter number : ");    
            String num = sc.next();
            pst= con.prepareStatement("update students set name = ?, number = ? where id=?");
            pst.setInt(3, n);
            pst.setString(1, name);
            pst.setString(2, num);
            pst.execute();
            
            
            
    }
    static void delete() throws SQLException
    {
            System.out.println("enter id : ");    
            int n=sc.nextInt();
            pst= con.prepareStatement("delete from students where id=?");
            pst.setInt(1, n);
            pst.execute();
            
    }
    public static void main(String[] args) {
        try {
             sc=new Scanner(System.in);
             con=DriverManager.getConnection("jdbc:mysql://localhost/student", "root", "230659");
             st= con.createStatement();
             int choice;
             do
           {    System.out.print(" 1.Display \n 2.Insert\n 3.Update\n 4.Delete\n enter yout Choice : ");
               choice=sc.nextInt();
               if(choice==1)
                   display();
               if(choice==2)
                   insert();
               if(choice==3)
                   update();
               if(choice==4)
                   delete();
           }while(choice !=0);
             
                    
            } catch (SQLException ex) {
            Logger.getLogger(Pstmt.class.getName()).log(Level.SEVERE, null, ex);
        }
                
    }
    
}
