
package Statements;

import java.sql.*;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Stmt {
   static Scanner sc;
   static Connection con;
   static Statement st;
   
    static void display() throws SQLException
    {
            ResultSet rs=st.executeQuery("select * from students");
            System.out.println("...... DATA ......");
            while(rs.next())
            {
                System.out.print(rs.getInt(1) + " ");
                System.out.print(rs.getString(2) + " ");
                System.out.println(rs.getString(3) + " ");
            }System.out.println("...................\n\n");
    
    }
    static void insert() throws SQLException
    {
            System.out.println("enter id : ");    
            int n=sc.nextInt();
            System.out.println("enter name : ");    
            String name = sc.next();
            System.out.println("enter number : ");    
            String num = sc.next();
            st.execute("insert into students values ("+n+",'"+name+"','"+num+"')");
            
    }
    
   static void update() throws SQLException
    {       System.out.println("enter id : ");    
            int n=sc.nextInt();
            System.out.println("enter name : ");    
            String name = sc.next();
            System.out.println("enter number : ");    
            String num = sc.next();
            st.execute("update students set name = '"+ name +"', number = '"+num+"' where id="+n+"");
            
    }
    static void delete() throws SQLException
    {       System.out.println("enter id : ");    
            int n=sc.nextInt();
            st.execute("delete from students where id="+n+"");
            
    }
    public static void main(String[] args) {
        try {
             sc=new Scanner(System.in);
             con=DriverManager.getConnection("jdbc:mysql://localhost/student", "root", "230659");
             st=con.createStatement();
             int choice;
             do
           {    System.out.print(" 1.Display \n 2.Insert\n 3.Update\n 4.Delete\n enter yout Choice : ");
               choice=sc.nextInt();
               if(choice==1)
                   display();
               if(choice==2)
                   insert();
               if(choice==3)
                   update();
               if(choice==4)
                   delete();
           }while(choice !=0);
             
                    
            } catch (SQLException ex) {
            Logger.getLogger(Stmt.class.getName()).log(Level.SEVERE, null, ex);
        }
                
    }
    
}
