
package UpdatableRS;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Insert {
    public static void main(String[] args) {
       String URL = "jdbc:mysql://localhost/student";
        try {
     
            Connection con = DriverManager.getConnection(URL,"root","230659");
            System.out.println("connection done");
            Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = st.executeQuery("select * from staff");
           
             rs.moveToInsertRow();
         
            rs.updateInt(1, 11);
            rs.updateString(2, "himanshu");
            rs.updateString(3, "444");
            rs.insertRow();
            System.out.println("row updated");
          
            while (rs.next())
            {
                System.out.print(rs.getInt(1)+" ");
                System.out.print(rs.getString(2)+" ");
                System.out.println(rs.getString(3)+" ");
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(Insert.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }
    
}
