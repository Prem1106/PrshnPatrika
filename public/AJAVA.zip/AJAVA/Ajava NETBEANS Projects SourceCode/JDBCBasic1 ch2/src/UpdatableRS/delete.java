
package UpdatableRS;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class delete {
    public static void main(String[] args) {
       String URL = "jdbc:mysql://localhost/student";
        try {
     
            Connection con = DriverManager.getConnection(URL,"root","230659");
            System.out.println("connection done");
            Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = st.executeQuery("select * from staff");
           rs.absolute(2);// move to 2nd row 
           rs.deleteRow();//delete 2nd row
           rs.absolute(1);// reset the cursor to display data
            while (rs.next())
            {
                System.out.print(rs.getInt(1)+" ");
                System.out.print(rs.getString(2)+" ");
                System.out.println(rs.getString(3)+" ");
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(delete.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }
    
}
