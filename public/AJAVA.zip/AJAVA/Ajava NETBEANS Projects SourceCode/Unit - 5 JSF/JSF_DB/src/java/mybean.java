
import java.io.Serializable;
import java.sql.*;
import java.util.ArrayList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
@ManagedBean
@RequestScoped
public class mybean implements Serializable{
    String name;
    String address;
    int number;
    int id;
   
    ArrayList<mybean> a = new ArrayList<mybean>();

    public ArrayList<mybean> getA() {
        return a;
    }

    public void setA(ArrayList<mybean> a) {
        this.a = a;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String dbinsert() throws SQLException, ClassNotFoundException
    {
        String ur = "jdbc:mysql://localhost:3306/staff";
        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection(ur,"root","");
        Statement st = con.createStatement();
        st.execute("insert into staff_info values("+id+",'"+name+"','"+address+"',"+number+")");
        return "success";
    }
    
    public ArrayList getDisplay() throws SQLException, ClassNotFoundException
    {
        String ur = "jdbc:mysql://localhost:3306/staff";
        
        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection(ur,"root","");
        Statement st = con.createStatement();
        ResultSet rs=st.executeQuery("select * from staff_info");
        while(rs.next())
        {mybean b = new mybean();
                b.id=rs.getInt(1);
                b.name=rs.getString(2);
                b.number=rs.getInt(4);
                b.address=rs.getString(3);
                
        a.add(b);
        b.setA(a);
        }
        
        return a;
    }
    
    
    
}
