
package AjavaNetworking.ClientServer;
import java.io.*;  
import java.net.*;
import java.util.Scanner;
public class client {
    
    public static void main(String args[])
    {Scanner sc = new Scanner(System.in);
            
            try{      
        Socket s=new Socket("localhost",8080);  
        DataOutputStream dout=new DataOutputStream(s.getOutputStream());  
        dout.writeInt(sc.nextInt());  
        dout.writeInt(sc.nextInt());  
        DataInputStream dis=new DataInputStream(s.getInputStream());  

                System.out.println(dis.readInt()) ;
        
        
        dout.flush();  
        dout.close();  
        s.close();  
        }catch(Exception e){System.out.println(e);}     
    
    
    }
    
}
