
package AjavaNetworking.ClientServer;
import java.io.*;  
import java.net.*;

public class server {

   
    public static void main(String[] args) {
        try{  
        ServerSocket ss=new ServerSocket(8080);  
        Socket s=ss.accept();//establishes connection   
            System.out.println("hello");
        DataInputStream dis=new DataInputStream(s.getInputStream());  
//        String  str =(String)dis.readUTF();
          int i = dis.readInt();
          int j = dis.readInt();
        System.out.println("message= "+ (i+j));  
        DataOutputStream dout=new DataOutputStream(s.getOutputStream());  
        dout.writeInt(i+j); 
        ss.close();  
        }catch(Exception e){System.out.println(e);}  
    }
    
}
