package AjavaNetworking;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.*;  
import java.net.*;  
public class URLexample{  
public static void main(String[] args){  
try{  
URL url1=new URL("http://10.9.150.45:8090/");  
URL url=new URL("http://cms.atmiya.edu.in/Index.aspx/");  
  
System.out.println("Protocol: "+url.getProtocol());  
System.out.println("Host Name: "+url.getHost());  
System.out.println("Port Number: "+url.getPort());  
System.out.println("File Name: "+url.getFile());  
  
}catch(Exception e){System.out.println(e);}  
}  
}  