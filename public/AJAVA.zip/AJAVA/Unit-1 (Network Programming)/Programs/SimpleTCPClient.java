import java.net.*;
import java.io.*;

public class SimpleTCPClient {
public static void main(String[] args){
		try
		{
			Socket s = new Socket("127.0.0.1", 8888);
			//Define read/write from socket
			PrintWriter out = new PrintWriter(s.getOutputStream(), true);
			
			BufferedReader in =new BufferedReader(new InputStreamReader(s.getInputStream()));
			//Send hello message
			String msg = "This is my text to be changed by the SERVER ";
			out.println(msg);
			//Receive a reversed message
			msg = in.readLine();
			System.out.println("Server : " + msg);
		}catch(IOException ioe){
			ioe.printStackTrace();
	}
}
}