import java.io.*;
import java.net.*;
/**
*/
public class SimpleTCPServer
		{
			public static void main(String[] args)
			{
	try{
			//Create server socket listening on port 8888
			ServerSocket ss = new ServerSocket(8888);
			while(true)
			{
				System.out.println("Waiting for client to connect...");
				 Socket s = ss.accept();
			//Create read/write from socket
			PrintWriter out = new PrintWriter(s.getOutputStream(), true);
			BufferedReader in =new BufferedReader(new InputStreamReader(s.getInputStream()));
			//client address
			InetAddress remoteIp = s.getInetAddress();
			//Receiving from client
			String msg = in.readLine();
			System.out.println("Client " + remoteIp + " : " + msg);
			//Sending a reversed string
			msg = reverseString(msg.trim());
			out.println(msg);
			}
		}catch(IOException ioe){
				ioe.printStackTrace();
			}
			}
			private static String reverseString(String input) {
				StringBuilder buf = new StringBuilder(input);
				return buf.reverse().toString();
			}
		}