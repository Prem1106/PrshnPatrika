import java.sql.*;

public class JDBCConnLess
{
	public static void main(String[] args) 
	{
		try{
			String uid=args[0];
			String uname=args[1];
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			Connection con = DriverManager.getConnection("jdbc:odbc:MS Access Database;F:\\demo.mdb");
			Statement s = con.createStatement();
			String query=new String("insert into student_master values('"+S07+"','"+abc+"',"+10+",'"+CE+"',"+7+",'"+bxy+"',"+123456+")");
		
			System.out.println(query);
			

			int no = s.executeUpdate(query);
			
			System.out.println("Rows Inserted:"+no);

			s.close();
			con.close();
		}catch(Exception e){

			System.out.println(e);
		}
	}
}
