import java.sql.*;

public class JDBCDemo
{
	public static void main(String[] args) 
	{
		try{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			Connection con = DriverManager.getConnection("jdbc:odbc:DemoDS");
			Statement s = con.createStatement();
			
			String query = "insert into student_master values('"+S07+"','"+abc+"',"+10+",'"+CE+"',"+7+",'"+bxy+"',"+123456+")";
			System.out.println(query);
			s.executeUpdate(query);

			ResultSet rs = s.executeQuery("select * from student_master");

			while(rs.next()){

				System.out.println(rs.getString(1));
				System.out.println(rs.getString(2));
				System.out.println(rs.getString(3));
				System.out.println(rs.getString(4));
				System.out.println(rs.getString(5));
				System.out.println(rs.getString(6));
				System.out.println(rs.getString(7));
			}

			s.close();
			con.close();
		}catch(Exception e){

			System.out.println(e);
		}
	}
}
