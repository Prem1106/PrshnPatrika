import java.sql.*;

public class JDBCPrepared
{
	public static void main(String[] args) 
	{
		try{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			Connection con = DriverManager.getConnection("jdbc:odbc:DemoDSN1");

			PreparedStatement s = con.prepareStatement("insert into student_master values(?,?,?,?,?,?,?)");
			s.setString(1,"s007");//stu_id
			s.setString(2,"aits1");//stu_name
			s.setString(3,"11");//roll_no
			s.setString(4,"CE");//branch
			s.setString(5,"6");//semester
			s.setString(6,"BX");//division
			s.setString(7,"999999999");//contact_no
			int n=s.executeUpdate();
			System.out.println("row inserted"+n);
			
			

			s.close();
			con.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
