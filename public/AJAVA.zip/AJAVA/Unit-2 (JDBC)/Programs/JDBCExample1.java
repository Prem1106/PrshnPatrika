
import java.sql.*;
public class JDBCExample1 
{
	public static void main(String args[]) throws SQLException, ClassNotFoundException
	{
//Using URL ,user name and password in oracle
		String driverClassName="sun.jdbc.odbc.JdbcOdbcDriver";
		String url="jdbc:odbc:mydsn";
		String username="system";
		String password="root";
		String query = "insert into Login values ('Nirali','J2ME')";
		//Load driver class 
		Class.forName (driverClassName);
		// obtain a connection
		Connection con=DriverManager. getConnection(url, username, password);
		// Obtain a Statement
		DatabaseMetaData dm=con.getMetaData();
		System.out.println(dm.getDatabaseProductName());
		System.out.println(dm.getUserName());
		Statement st=con. createStatement();
		//Execute the Query
		int count=st.executeUpdate (query);
		
 		System.out.println ("Number of rows effected by this query = "+count);
		ResultSet rs=st.executeQuery("select * from Login");
		ResultSetMetaData rsm=rs.getMetaData();
		System.out.println(rsm.getColumnCount());
		System.out.println(rsm.getColumnName(1));
		System.out.println(rsm.getColumnTypeName(1));
		
		// Closing the connection as our requirement with connection is 
 		
		con.close();
	}
}
