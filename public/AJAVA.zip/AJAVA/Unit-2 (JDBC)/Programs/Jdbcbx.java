import java.sql.*;

class Jdbcbx
{
     public static void main(String [] args)
	 {
	 try
	 {
		 Class.forName("org.sqlite.JDBC");
		 Connection con=DriverManager.getConnection("jdbc:sqlite:F:\\sqlite\\testbx");
		 Statement s=con.createStatement();
		 int n=s.executeUpdate("insert into test1 values(2,'AIP')");
		 System.out.println("row inserted is"+n);
		 ResultSet rs=s.executeQuery("select * from test1");
		 while(rs.next())
		 {
			 System.out.print(rs.getInt(1)+"\t");
			 System.out.println(rs.getString(2));
			 
		 }
		 rs.close();
		 s.close();
		 con.close();
	 }
	 catch(Exception e)
	 {
	 System.out.println(e);
	 }
	 }
}