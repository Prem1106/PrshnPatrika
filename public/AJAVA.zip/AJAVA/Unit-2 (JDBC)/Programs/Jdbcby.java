import java.sql.*;

class Jdbcby
{
     public static void main(String args[])
	 {
	 try
	 {
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con=DriverManager.getConnection("jdbc:odbc:by1");
		PreparedStatement ps=con.prepareStatement("insert into student_master values(?,?,?,?,?,?,?)");
		ps.setString(1,"888");
		ps.setString(2,"aits");
		ps.setInt(3,15);
		ps.setString(4,"CE");
		ps.setInt(5,6);
		ps.setString(6,"BY");
		ps.setInt(7,9898989);
		int n=ps.executeUpdate();
		System.out.println("row inserted is"+n);
		ps.close();
		con.close();
		
	 
	 }
	 catch(Exception e)
	 {
	 System.out.println(e);
	 }
	 }
}