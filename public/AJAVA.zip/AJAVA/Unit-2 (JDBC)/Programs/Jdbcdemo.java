import java.sql.*;

class Jdbcdemo
{
      public static void main(String []args)
	  {
	  try
	  {
	  Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
	  Connection con=DriverManager.getConnection("jdbc:odbc:test1");
	  Statement s=con.createStatement();
	  String query=new String("insert into test values("+104+",'abcs')");
	  int a=s.executeUpdate(query);
	  System.out.println("1 row inserted"+a);
	  ResultSet rs=s.executeQuery("select * from test");
	  while(rs.next())
	  {
	  System.out.println(rs.getString(1));
	  System.out.println(rs.getString(2));
	 
	  }
	  s.close();
	  con.close();
	  }
	  catch(Exception e)
	  {
	   System.out.println(e);
	  }
	  }
}