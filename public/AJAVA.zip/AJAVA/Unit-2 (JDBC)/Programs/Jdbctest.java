import java.sql.*;


class Jdbctest
{
      public static void main (String []args)
	  {
		  try
		  {
			
			  Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			  Connection con=DriverManager.getConnection("jdbc:odbc:MS Access Database;DBQ=F:\\Database2.accdb");
			  PreparedStatement ps=con.prepareStatement("insert into test values(?,?)");
               ps.setInt(1,200);
			   ps.setString(2,"java");
			   int n=ps.executeUpdate();
			   System.out.println("row inserted is"+n);
			   ps.setInt(1,300);
			   ps.setString(2,"j2ee");
			   int n1=ps.executeUpdate();
			   System.out.println("row inserted is"+n1);
			  
			  
			  con.close();
		  }
		  catch(Exception e)
		  {
			  System.out.println(e);
		  }
	  
	  }

}