import java.sql.*;
import java.util.*;

class Jdbctest1
{
	public static void main(String []args)
	{
		try
		{
			
			
			Class.forName("org.sqlite.JDBC");
			Connection con = DriverManager.getConnection("jdbc:sqlite:F:\\sqlite\\test");
			Statement s=con.createStatement();
			
			ResultSet rs=s.executeQuery("select * from S_info");
			while(rs.next())
			{
				System.out.print(rs.getInt(1)+"\t");
				System.out.print(rs.getString(2)+"\t");
				
			}
			rs.close();
			s.close();
			con.close();
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}