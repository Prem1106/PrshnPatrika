import java.sql.*;
public class Prog1 {
	public static void main(String s[]) throws Exception {
 	Class.forName("oracle.jdbc.driver.OracleDriver");
	Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","admin");
	con.setAutoCommit(false);
	Statement s1=con.createStatement();
	ResultSet rs=s1.executeQuery("select EN,Sname from student");
	while(rs.next())
	{
		System.out.print(rs.getInt(1)+"\t");
		System.out.print(rs.getString(2)+"\n");
		
	}
	Savepoint sp=con.setSavepoint("row_delete");
	s1.executeUpdate("delete from student where EN>102");
	con.rollback(sp);
	con.commit();
	rs.close();
	s1.close();
	con.close();
	}
}