import java.sql.*;

public class ResultSetMetaDataEX
{

public static void main(String [] args)
{
	
	try
	{
		Class.forName("oracle.jdbc.driver.OracleDriver");  
		Connection con=DriverManager.getConnection
		( "jdbc:oracle:thin:@localhost:1521:xe","system","admin");
		
		
		
		Statement s=con.createStatement();
		ResultSet rs=s.executeQuery("select * from student");
		ResultSetMetaData rsm=rs.getMetaData();
		System.out.println(rsm.getColumnCount());
		System.out.println(rsm.getColumnName(1));
		System.out.println(rsm.getColumnTypeName(1));
		
		
		s.close();
con.close();
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	
	
	
}
}

		