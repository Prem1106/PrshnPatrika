import java.sql.*;
import java.io.*;  
class S1{  
public static void main(String args[]){  
	try
	{
Class.forName("oracle.jdbc.driver.OracleDriver");  
Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","admin");  
con.setAutoCommit(false);
PreparedStatement ps=con.prepareStatement("insert into student values(?,?,?)");
BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
while(true)
{
System.out.println("enter En");
int en=Integer.parseInt(br.readLine());
System.out.println("enter Sname");
String sn=br.readLine();
System.out.println("enter result");
int res=Integer.parseInt(br.readLine());
    ps.setInt(1,en);
	ps.setString(2,sn);
	ps.setInt(3,res);
	ps.executeUpdate();
	System.out.println("commit/rollback");
	String str=br.readLine();
	if(str.equals("commit"))
	{
		con.commit();
	}
	System.out.println("Y/N?");
	int str1=br.read();
	if(str1=='n')
	{
		break;
	}
}
	con.commit();
	con.close();
	
	}
	catch(Exception e)
	{
	System.out.println(e);
	}
}
}
