import java.sql.*;

public class UpdatableResult
{

public static void main(String [] args)
{
	
	try
	{
Class.forName("oracle.jdbc.driver.OracleDriver");  
Connection con=DriverManager.getConnection
( "jdbc:oracle:thin:@localhost:1521:xe","system","admin");              
Statement  s = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
 ResultSet rs = s.executeQuery("select EN,Sname from student");
            while(rs.next()){
                if(rs.getInt(1) == 101){
                    rs.updateString(2, "classBY");
                    rs.updateRow();
                    System.out.println("Record updated!!!");
                }
            }
		rs.close();
		s.close();
		con.close();
		}
catch(Exception e)
{
System.out.println(e);
}

}
}
	