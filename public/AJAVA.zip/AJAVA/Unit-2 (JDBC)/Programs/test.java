import java.sql.*;
//Using command line argument,insert data in the database
public class test
{

public static void main(String []args)
{

try
{
String un=args[0];
String pwd=args[1];

Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection con=DriverManager.getConnection("jdbc:odbc:DemoDSN");
Statement s=con.createStatement();
int no=s.executeUpdate("insert into student_master values('"+un+"','"+pwd+"')");     
System.out.println("no of row inserted is"+no);
s.close();
con.close();
}
catch(Exception e)
{
System.out.println(e);
}
}
}