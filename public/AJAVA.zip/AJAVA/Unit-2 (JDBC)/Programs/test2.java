import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class test2 extends JFrame implements ActionListener
{

JLabel l1,l2;
JTextField t1,t2;
JButton b1,b2,b3,b4;
Connection con;
Statement s;
ResultSet rs;

test2()
{
     setLayout(new GridLayout(4,2));
     l1=new JLabel("id");
     l2=new JLabel("Studentname");
     t1=new JTextField(10);
     t2=new JTextField(10);
     b1=new JButton("insert");
     b2=new JButton("previous");
	b3=new JButton("update");
	b4=new JButton("next");
	b1.addActionListener(this);
	b2.addActionListener(this);
	b3.addActionListener(this);
	b4.addActionListener(this);
	b1.setActionCommand("insert");
	b2.setActionCommand("previous");
	b3.setActionCommand("update");
	b4.setActionCommand("next");
	add(l1);
	add(t1);
	add(l2);
	add(t2);
	add(b1);
	add(b2);
	add(b3);
	add(b4);
	
	try
	{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		con=DriverManager.getConnection("jdbc:odbc:DemoDSN");
		/*DatabaseMetaData dm=con.getMetaData();
		System.out.println(dm.getDatabaseProductName());*/
		
		
		s=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
		rs=s.executeQuery("select * from student_master");
		ResultSetMetaData rsm=rs.getMetaData();
		System.out.println(rsm.getColumnCount());
		System.out.println(rsm.getColumnName(1));
		System.out.println(rsm.getColumnTypeName(1));
		
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
}

public void actionPerformed(ActionEvent ae)
{
	if(ae.getActionCommand().equals("insert"))
	{
		String un=t1.getText();
		String pwd=t2.getText();
		try
		{
				int no=s.executeUpdate("insert into student_master values ('"+un+"','"+pwd+"')");
				JOptionPane.showMessageDialog(this,"No of Data inserted"+no);		
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}
	
	if(ae.getActionCommand().equals("previous"))
	{
		try
		{
			//rs.relative(-2);
			//rs.updateString("uname",t2.getText());
			rs.updateString(1,"XNirali1");
			rs.updateString(2,"Atmiya");
			rs.insertRow();
			//rs.updateString("uname","nir");
		//rs.updateRow();
		//	System.out.println(rs.getRow());
			if(rs.previous())
			{
					t1.setText(rs.getString(1));
					t2.setText(rs.getString(2));
			}
		}
		catch(Exception e)
		{
		}
	}
	
	if(ae.getActionCommand().equals("next"))
	{
		//in constructor
		try
		{
			
			if(rs.next())
			{
					t1.setText(rs.getString(1));
					t2.setText(rs.getString(2));
			}
		}
		catch(Exception e)
		{
		}
		
	}
	
if(ae.getActionCommand().equals("update"))
	{
		//in constructor
		String un=t1.getText();
		String pwd=t2.getText();
		try
		{
		int no=s.executeUpdate("update student_master  SET password='"+pwd+"' where uname='"+un+"'");
		}
		catch(Exception e)
		{
		}
		
	}
	
}
	public static void main(String []args)
	{
		test2 t=new test2();
		t.setTitle("sql query demo");
		t.setVisible(true);
		t.setSize(350,500);
		t.setResizable(false);
		t.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
















































