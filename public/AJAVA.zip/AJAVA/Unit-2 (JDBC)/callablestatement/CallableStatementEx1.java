
import java.sql.*;
/**
 * @author Nirali
 */
public class CallableStatementEx1 {
	public static void main(String s[]) throws Exception {
		
		Class.forName("oracle.jdbc.driver.OracleDriver");  
		Connection con=DriverManager.getConnection(  
		"jdbc:oracle:thin:@localhost:1521:xe","system","admin"); 		
		// Get CallableStatement
		CallableStatement cs= con.prepareCall("{call createAccount2(?,?,?,?,?,?)}");		
		// set IN parameters
		cs.setInt(1,107);
		cs.setInt(2,12);
		cs.setString(3,"XYZ");
		cs.setDouble(4,200000);
		cs.setString(5,"Mumbai");
		cs.setInt(6,123456789);		
		// register OUT parameters
		//In this procedure example we don�t have OUT parameters 
		//executing the stored procedure
		cs.execute();
		System.out.println("Account Created");		
		con.close();
	}//main
}//class
