
import java.sql.*;

public class CallableStatementEx2 {
	public static void main(String s[]) throws Exception {
		
		Class.forName("oracle.jdbc.driver.OracleDriver");  
		Connection con=DriverManager.getConnection(  
		"jdbc:oracle:thin:@localhost:1521:xe","system","admin"); 		
		// Get CallableStatement
		CallableStatement cs= con.prepareCall("{call getBalance(?,?)}");		
		cs.setInt(1,Integer.parseInt(s[0]));
		cs.registerOutParameter(2,Types.DOUBLE);
		cs.execute();
		System.out.println("balance:"+cs.getDouble(2));
	}
}
