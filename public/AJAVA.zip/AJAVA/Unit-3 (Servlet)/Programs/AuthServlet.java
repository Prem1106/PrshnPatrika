/*
 * AuthServlet.java
 *
 * 
 */

import java.io.*;
import java.net.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class AuthServlet extends HttpServlet {
    
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
    }
    
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html");
        
        PrintWriter out = response.getWriter();
        
        String name = request.getParameter("username");
        
        String password = request.getParameter("password");
        boolean flg=false;
        try{
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection con = DriverManager.getConnection("jdbc:odbc:t1");
            Statement s = con.createStatement();
            ResultSet rs = s.executeQuery("select * from auth");
            
            while(rs.next()){
                if(rs.getString(1).equals(name)&&rs.getString(2).equals(password)){
                    flg=true;
  out.println("User is  valid");
                    s.close();
                    con.close();
                    
                }
            }
            
            if(flg==false){
                out.println("User is not valid");
                s.close();
                con.close();
            }
            
        }catch(Exception e){
            out.println(e);
        }
        
        
    }
}
