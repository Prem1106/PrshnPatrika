import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class Login extends HttpServlet
{
	protected void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException
	{
		String un=req.getParameter("uname");
		String pw=req.getParameter("pass");
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		if(un.equals("123")&&pw.equals("123"))
		{
			out.println("login success");
		}
	}
}